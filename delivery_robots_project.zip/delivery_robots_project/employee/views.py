from django.shortcuts import render
from django.contrib.auth.decorators import login_required


@login_required()
def logged_employee(request):
    return render(request, 'employee/logged_employee.html')

@login_required()
def orders(request):
    return render(request, 'employee/orders.html')