from django.apps import AppConfig


class PizzeriaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pizzeria'
